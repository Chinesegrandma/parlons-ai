Parlons AI — offline demo with Camille
Open parlons-demo.html. Scripted replies and tones only; no API calls or speech recognition quality validation.
Use the running app for microphone conversation mode.
