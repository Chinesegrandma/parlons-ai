Parlons AI — offline interactive demo
Open parlons-demo.html in a browser.
Category-first practice, Chinese/English UI, scripted replies and local notebook.
No API keys or real provider calls. Audio is a tone, not French speech.
Hands-free microphone mode is available in the running web app, not this offline demo.
