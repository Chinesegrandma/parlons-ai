Parlons 聊天布局预览
解压后打开 HTML。
发送 J’aime cette musique.，点击表达选项，再选俚语，可查看 kiffer 示例及 verlan 小词典。
发送 Je voudrais une café.，可查看直接显示的修正版，并展开解释。
这是模拟演示，不调用真实 API，不验证语言或语音质量，不代表当前用语流行度。
