Parlons dev 最新交互预览
解压后打开 HTML。
每条 AI 回复有听一遍、0.8×、翻译、复制。音频是提示音，不是真实法语。
社交→发出邀请，输入 En semaine, je prépare un entretien, donc plutôt samedi. 可演示先关心面试再回到约时间；这是专门配置的预设示例，不代表模型理解能力。
不调用真实 API、不打开真实麦克风。
