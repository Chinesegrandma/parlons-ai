Parlons 聊天布局交互预览
解压后打开 HTML。
逐句练习中发送 Je voudrais une café.，下方直接显示修正版 Je voudrais un café.。
点击修正版展开解释及其他表达方式。
演示使用预设回复和提示音，不调用真实 API。
