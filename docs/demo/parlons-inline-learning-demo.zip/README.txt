Parlons A 方案交互预览
解压后打开 HTML。
发送 Je voudrais une café.，点击修正版。纠错与解释保留在主卡，下方的更礼貌、俚语是可选展开项。
使用预设回复和提示音，不调用真实 API。
