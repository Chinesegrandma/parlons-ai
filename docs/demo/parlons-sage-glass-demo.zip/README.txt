Parlons 鼠尾草玻璃设计预览
解压后用浏览器打开 Parlons-Sage-Glass.html。
这是离线交互演示：使用预设回复，不消耗 API 额度，不测试真实语音质量。
完整功能请启动本分支的应用。
